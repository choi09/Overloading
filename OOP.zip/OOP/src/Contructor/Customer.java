/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Contructor;

/**
 *
 * @author LENOVO
 */
public class Customer {
   String Nama;
   int umur;
   
   
   Customer () {
       System.out.println("Constructor pertama");
   }
   
   Customer (String Nama) {
       System.out.println("Constructor kedua");
   }
   
   Customer (String Nama , int umur) {
       System.out.println("Constructor ketiga");
   }
   
   void alamat(){
   }
}
