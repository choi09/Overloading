/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overload;

/**
 *
 * @author LENOVO
 */
public class aplikasii {
    public static void main (String[] args){
    
        
    menghitung objek = new menghitung ();
    int penjumlahan1 =objek.penjumlahan(35,20);
    int penjumlahan2 =objek.penjumlahan(35,20,15);
    
    System.out.println("penjumlahan dengan 2 parameter"+ penjumlahan1);
    System.out.println("penjumlahan dengan 3 parameter"+ penjumlahan2);
    }
    
}
